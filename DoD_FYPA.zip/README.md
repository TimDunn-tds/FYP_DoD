# UoN Mechatronics FYP Report LaTeX template

Project report template suitable for UoN Mechatronics students undertaking a FYP.
This may also be used for other course project reports, such as MCHA3000.


Demonstrates use of:

* Table of contents
* Hyperlinks
* Figures
* Tables
* Simple math environments
* Unnumbered sections (Abstract, Acknowledgements etc.)
* Bibtex database
* Source code listings